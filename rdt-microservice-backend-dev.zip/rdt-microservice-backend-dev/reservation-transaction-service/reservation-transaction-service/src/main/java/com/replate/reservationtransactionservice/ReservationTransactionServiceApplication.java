package com.replate.reservationtransactionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservationTransactionServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReservationTransactionServiceApplication.class, args);
    }

}
