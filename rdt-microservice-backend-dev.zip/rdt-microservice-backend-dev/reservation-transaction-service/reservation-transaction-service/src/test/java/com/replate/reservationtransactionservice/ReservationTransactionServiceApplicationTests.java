package com.replate.reservationtransactionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationTransactionServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
