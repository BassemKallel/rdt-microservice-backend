package com.replate.usermanagementservice.dto;

public class UserResponse {
    private String username;
    private String email;
    private String role;
    private Boolean isVerified;
}
