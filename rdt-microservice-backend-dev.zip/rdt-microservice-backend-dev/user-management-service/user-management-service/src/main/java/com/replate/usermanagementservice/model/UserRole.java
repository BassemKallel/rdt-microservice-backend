package com.replate.usermanagementservice.model;

public enum UserRole {
    INDIVIDUAL,
    MERCHANT,
    ASSOCIATION,
    ADMIN
}