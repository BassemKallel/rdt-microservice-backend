package com.replate.reportingsafetyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportingSafetyServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
