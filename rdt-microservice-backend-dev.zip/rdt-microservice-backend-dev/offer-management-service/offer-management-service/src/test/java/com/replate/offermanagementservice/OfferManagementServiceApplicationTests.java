package com.replate.offermanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfferManagementServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
