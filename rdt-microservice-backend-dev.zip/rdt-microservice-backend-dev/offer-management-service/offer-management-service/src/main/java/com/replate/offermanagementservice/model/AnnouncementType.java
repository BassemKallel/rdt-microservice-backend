package com.replate.offermanagementservice.model;

public enum AnnouncementType {
    SALE,        // Vente d'un produit
    DONATION     // Don d'un produit
}